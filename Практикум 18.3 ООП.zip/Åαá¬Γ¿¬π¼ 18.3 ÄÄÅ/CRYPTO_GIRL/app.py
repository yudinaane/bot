import telebot


TOKEN = '5807603946:AAHzGOERKRGkqGm7ZC7XrkD0Zjp6DCyJTiU'


bot = telebot.TeleBot(TOKEN)


@bot.message_handler()
def echo_test(message: telebot.types.Message):
    bot.send_message(message.chat.id, 'hello')


bot.polling
